/**
 * Create an immediately-invoked function expression that returns a static object.
 * This is to be available globally via the variable "app" (aka "window.app").
 */
var app = (function(){
    "use strict";

    /***** Variables / Objects / Overrides *****/

    // Set private flag for application to output messages.
    var useDebugs = false;

    // Set name for any application context.
    var contextName = "MonitorContext";

    // Set the language code according to browser preference.
    // Only English (default), Spanish, and French are currently supported.
    var langCode = spark.getCookie("language");
    if (langCode === "") {
        langCode = window.navigator.language;
    }

    // Normalize the given language code.
    switch(langCode){
        case "es":
        case "es-ES":
            // Spanish
            langCode = "es-ES";
            break;
        case "fr":
        case "fr-FR":
            // French
            langCode = "fr-FR";
            break;
        default:
            // English
            langCode = "en-US";
            break;
    };
    spark.setCookie("language", langCode);

    // Append appropriate culture as based on the browser.
    $.getScript("vendor/kendo/js/cultures/kendo.culture." + langCode + ".min.js")
        .done(function(){
            kendo.culture(langCode);
        });

    // Append appropriate messages as based on the browser.
    $.getScript("vendor/kendo/js/messages/kendo.messages." + langCode + ".min.js")
        .done(function(){
            kendo.culture(langCode);
        });

    // Set defaults for AuthN errors on Kendo DataSource.
    kendo.data.DataSource.prototype.options.error = function(ev){
        if (ev.xhr.status === 401 || ev.xhr.status === 403) {
             console.warn("Your session has expired.");
             app.doLogoutAction();
        }
    };

    /***** Helper Functions *****/

    function logMessage(message, always){
        if ((useDebugs || always) && console && console.log) {
            console.log(message);
        }
    }

    function updateStyles(){
        setTimeout(function(){
            // Convert bootstrap tooltip objects.
            $("[data-toggle=tooltip]").tooltip();
            // Convert bootstrap popover objects.
            $("[data-toggle=popover]").popover();
        }, 100);
    }

    function messageHandler(data){
        if (notify && data && data.messages) {
            $.each(data.messages, function(i, message){
                notify.showMessage(message.messageText, message.messageType);
            });
        }
    }

    /***** Application Customizations *****/

    function getLanguageStrings(languagePref){
        // Update local variable with new (normalized) language code.
        switch(languagePref){
            case "es":
            case "es-ES":
                // Spanish
                langCode = "es-ES";
                break;
            case "fr":
            case "fr-FR":
                // French
                langCode = "fr-FR";
                break;
            default:
                // English
                langCode = "en-US";
                break;
        };
        spark.setCookie("language", langCode);

        // Determine the proper language abbreviation based on preference.
        if (langCode && !kendo.cultures[langCode]) {
            // Only load the appropriate culture files for KendoUI if not present.
            $.getScript("vendor/kendo/js/cultures/kendo.culture." + langCode + ".min.js")
                .done(function(){
                    kendo.culture(langCode);
                });
            $.getScript("vendor/kendo/js/messages/kendo.messages." + langCode + ".min.js")
                .done(function(){
                    kendo.culture(langCode);
                });
        }
        if (!window.local || !local.strings || !local.strings[langCode]) {
            // Append appropriate application strings as based on the current language.
            $.getScript("assets/js/local.strings." + langCode + ".js")
                .done(function(){
                    if (local && local.strings && local.strings[langCode]) {
                        local.strings.current = local.strings[langCode];
                    }
                });
        }
    }

    function getText(originalText){
        // Returns a translated string, if available.
        if (local && local.strings && local.strings.current) {
            if (local.strings.current.application[originalText]) {
                // Return a general application string from static data.
                return local.strings.current.application[originalText];
            }
        }

        // Return a translated string from the internal library.
        // If a string does not exist, return original text as-is.
        return spark.strings.getTranslatedString(originalText);
    }

    function showMessage(message, type){
        if (notify) {
            notify.showMessage(message, type);
        } else {
            console.log(message, type);
        }
    }

    function showMessages(responseObject){
        if (notify) {
            notify.showMessages(responseObject);
        }
    }

    function translateView(selector){
        // Run standard translation using a specific method.
        spark.form.translateForm(selector, getText, {showRequiredIndicator: true});
    }

    function getAppContext(){
        var context = spark.getSessionObject(contextName);
        if (!context || context === "") {
            context = {}; // Default to an empty object.
            spark.setSessionObject(contextName, {});
        }
        return context;
    }

    function setAppContext(data){
        var context = getAppContext();
        if (typeof(data) === "object") {
            $.each(data, function(name, value){
                // Update only the passed object properties.
                context[name] = value;
            });
        }
        spark.setSessionObject(contextName, context);
        return context;
    }

    /***** Application *****/

    var appHost = window.location.hostname || "localhost";
    var appPort = window.location.port || "8850";
    var fldAppName = null;
    var lastAppName = ""; // Should be set to the last selected application/server.
    function initContent(){
        fldAppName = $("#mainContent input[name=applicationList]").kendoDropDownList({
            dataSource: new kendo.data.DataSource(),
            select: function(e){
                var item = e.item || {};
                lastAppName = this.dataItem(item.index()) || {};
            }
        }).getKendoDropDownList();

        $("#tabstrip").kendoTabStrip({
            animation: false,
            collapsible: false
        });
        var tabStrip = $("#tabstrip").getKendoTabStrip();
        if (tabStrip) {
            tabStrip.select(0); // Select (expand) the first tab by default.
        }

        // Get the initial data for the monitor, starting with an application list.
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: "",
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/intake/applications",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.applicationNames) {
                    // Update the selection list with results.
                    var names = data.applicationNames || [];
                    fldAppName.dataSource.data(names);
                    if (names.length > 0) {
                        fldAppName.select(0);
                        lastAppName = names[0];
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
            }
        });
    }

    function loadMetrics(data){
        kendo.ui.progress($(document.body), true);

        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(data),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/intake/ablMetrics",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.success) {
                    showMessage(lastAppName + ": Processing Completed @ " + data.processed, "success");
                } else {
                    showMessage("Load operation failed. See intake.log for details.", "error");
                }
                kendo.ui.progress($(document.body), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                    kendo.ui.progress($(document.body), false);
                }
            }
        });
    }

    function buildParams(){
        var appServer = lastAppName.split("/");
        return {
            serverName: appServer[0],
            applicationName: appServer[1],
            processObjects: null,
            processProfiles: null,
            processRequests: null,
            processSessions: null
        }
    }

    function loadAccess(){
        kendo.ui.progress($(document.body), true);

        var appServer = lastAppName.split("/");
        var params = {
            serverName: appServer[0],
            applicationName: appServer[1]
        };

        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(params),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/intake/accessLogs",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.success) {
                    showMessage(lastAppName + ": Processing Completed @ " + data.processed, "success");
                } else {
                    showMessage("Load operation failed. See intake.log for details.", "error");
                }
                kendo.ui.progress($(document.body), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                    kendo.ui.progress($(document.body), false);
                }
            }
        });
    }

    function purgeMetrics(){
        kendo.ui.progress($(document.body), true);

        var appServer = lastAppName.split("/");
        var params = {
            serverName: appServer[0],
            applicationName: appServer[1],
            purgeDate: null
        };

        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(params),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/intake/purgeMetrics",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.success) {
                    showMessage(lastAppName + ": Metrics Expunge Completed @ " + data.processed, "success");
                } else {
                    showMessage("Purge operation failed. See agent log for details.", "error");
                }
                kendo.ui.progress($(document.body), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                    kendo.ui.progress($(document.body), false);
                }
            }
        });
    }

    function purgeHealth(){
        kendo.ui.progress($(document.body), true);

        var appServer = lastAppName.split("/");
        var params = {
            serverName: appServer[0],
            applicationName: appServer[1],
            purgeDate: null
        };

        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(params),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/intake/purgeHealth",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.success) {
                    showMessage(lastAppName + ": Health Expunge Completed @ " + data.processed, "success");
                } else {
                    showMessage("Purge operation failed. See agent log for details.", "error");
                }
                kendo.ui.progress($(document.body), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                    kendo.ui.progress($(document.body), false);
                }
            }
        });
    }

    /***** Initialization *****/

    // Create a VM to be used by the header.
    var headerVM = kendo.observable({
        headerTitle: "Data Administration",
        goToIndex: function(){
            location.href = "/static/";
        }
    });

    // Create a VM to be used by the content.
    var contentVM = kendo.observable({
        loadSessions: function(){
            var params = buildParams();
            params.processSessions = true;
            loadMetrics(params);
        },
        loadObjects: function(){
            var params = buildParams();
            params.processObjects = true;
            loadMetrics(params);
        },
        loadRequests: function(){
            var params = buildParams();
            params.processRequests = true;
            loadMetrics(params);
        },
        loadProfiles: function(){
            var params = buildParams();
            params.processProfiles = true;
            loadMetrics(params);
        },
        loadAccess: loadAccess,
        purgeMetrics: purgeMetrics,
        purgeHealth: purgeHealth
    });

    $(document).ready(function(){
        // Load current culture.
        kendo.culture(langCode);

        kendo.bind($("#mainHeader"), headerVM); // Bind VM to header.
        kendo.bind($("#mainContent"), contentVM); // Bind VM to content.

        // Get text replacements based on language.
        getLanguageStrings("en-US");

        updateStyles(); // Load any default styles.
        initContent(); // Create content widgets.
    });

    /***** Public Object *****/

    return {
        logMessage: logMessage,
        showMessage: showMessage,
        showMessages: showMessages,
        translateView: translateView,
        getText: getText,
        headerVM: headerVM,
        getAppContext: getAppContext,
        setAppContext: setAppContext
    };

})();