/**
 * Create an immediately-invoked function expression that returns a static object.
 * This is to be available globally via the variable "app" (aka "window.app").
 */
var app = (function(){
    "use strict";

    /***** Variables / Objects / Overrides *****/

    // Set private flag for application to output messages.
    var useDebugs = false;

    // Set name for any application context.
    var contextName = "MonitorContext";

    // Set the language code according to browser preference.
    // Only English (default), Spanish, and French are currently supported.
    var langCode = spark.getCookie("language");
    if (langCode === "") {
        langCode = window.navigator.language;
    }

    // Normalize the given language code.
    switch(langCode){
        case "es":
        case "es-ES":
            // Spanish
            langCode = "es-ES";
            break;
        case "fr":
        case "fr-FR":
            // French
            langCode = "fr-FR";
            break;
        default:
            // English
            langCode = "en-US";
            break;
    };
    spark.setCookie("language", langCode);

    // Append appropriate culture as based on the browser.
    $.getScript("vendor/kendo/js/cultures/kendo.culture." + langCode + ".min.js")
        .done(function(){
            kendo.culture(langCode);
        });

    // Append appropriate messages as based on the browser.
    $.getScript("vendor/kendo/js/messages/kendo.messages." + langCode + ".min.js")
        .done(function(){
            kendo.culture(langCode);
        });

    // Set defaults for AuthN errors on Kendo DataSource.
    kendo.data.DataSource.prototype.options.error = function(ev){
        if (ev.xhr.status === 401 || ev.xhr.status === 403) {
             console.warn("Your session has expired.");
             app.doLogoutAction();
        }
    };

    /***** Helper Functions *****/

    function logMessage(message, always){
        if ((useDebugs || always) && console && console.log) {
            console.log(message);
        }
    }

    function updateStyles(){
        setTimeout(function(){
            // Convert bootstrap tooltip objects.
            $("[data-toggle=tooltip]").tooltip();
            // Convert bootstrap popover objects.
            $("[data-toggle=popover]").popover();
        }, 100);
    }

    function messageHandler(data){
        if (notify && data && data.messages) {
            $.each(data.messages, function(i, message){
                notify.showMessage(message.messageText, message.messageType);
            });
        }
    }

    function getAgentSessionInfo(){
        return ("A" + (getAppContext().lastAgentPID || "") + " S" + (getAppContext().lastSessionID || ""));
    }

    function getSimpleServerName(){
        return (getAppContext().lastServerName || "Unknown").replace("_", " - ");
    }

    function getFileSafeServerName(){
        return (getAppContext().lastServerName || "Unknown").replace(/\./g, "-").replace(":", "_");
    }

    /***** Application Customizations *****/

    function getLanguageStrings(languagePref){
        // Update local variable with new (normalized) language code.
        switch(languagePref){
            case "es":
            case "es-ES":
                // Spanish
                langCode = "es-ES";
                break;
            case "fr":
            case "fr-FR":
                // French
                langCode = "fr-FR";
                break;
            default:
                // English
                langCode = "en-US";
                break;
        };
        spark.setCookie("language", langCode);

        // Determine the proper language abbreviation based on preference.
        if (langCode && !kendo.cultures[langCode]) {
            // Only load the appropriate culture files for KendoUI if not present.
            $.getScript("vendor/kendo/js/cultures/kendo.culture." + langCode + ".min.js")
                .done(function(){
                    kendo.culture(langCode);
                });
            $.getScript("vendor/kendo/js/messages/kendo.messages." + langCode + ".min.js")
                .done(function(){
                    kendo.culture(langCode);
                });
        }
        if (!window.local || !local.strings || !local.strings[langCode]) {
            // Append appropriate application strings as based on the current language.
            $.getScript("assets/js/local.strings." + langCode + ".js")
                .done(function(){
                    if (local && local.strings && local.strings[langCode]) {
                        local.strings.current = local.strings[langCode];
                    }
                });
        }
    }

    function getText(originalText){
        // Returns a translated string, if available.
        if (local && local.strings && local.strings.current) {
            if (local.strings.current.application[originalText]) {
                // Return a general application string from static data.
                return local.strings.current.application[originalText];
            }
        }

        // Return a translated string from the internal library.
        // If a string does not exist, return original text as-is.
        return spark.strings.getTranslatedString(originalText);
    }

    function showMessage(message, type){
        if (notify) {
            notify.showMessage(message, type);
        } else {
            console.log(message, type);
        }
    }

    function showMessages(responseObject){
        if (notify) {
            notify.showMessages(responseObject);
        }
    }

    function translateView(selector){
        // Run standard translation using a specific method.
        spark.form.translateForm(selector, getText, {showRequiredIndicator: true});
    }

    function getAppContext(){
        var context = spark.getSessionObject(contextName);
        if (!context || context === "") {
            context = {}; // Default to an empty object.
            spark.setSessionObject(contextName, {});
        }
        return context;
    }

    function setAppContext(data){
        var context = getAppContext();
        if (typeof(data) === "object") {
            $.each(data, function(name, value){
                // Update only the passed object properties.
                context[name] = value;
            });
        }
        spark.setSessionObject(contextName, context);
        return context;
    }

    /***** Application *****/

    var appHost = window.location.hostname || "localhost";
    var appPort = window.location.port || "8850";
    var agentSessions = [];
    var fldAppServer = null;
    var fldSampleGroup = null;

    function setAppServer(selected){
        // Remember the last appserver selected.
        var context = getAppContext();
        context.lastServerUUID = selected.appServerUUID;
        context.lastServerName = selected.serverName + "_" + selected.applicationName;
        setAppContext(context);

        // Return to the overview tab when changing AppServer.
        changeTab("overview");

        // Set the list of sample groups to choose from.
        var sampleGroup = "";
        if (fldSampleGroup) {
            var sampleGroups = selected.sampleGroup || [];
            var selectedGroup = 0;
            var groupNames = ["All"];
            var sampleGroup = context.lastSampleGroup[context.lastServerUUID] || "";

            // Last-stored group is not the default/all, so find the index of the current group name.
            $.each(sampleGroups, function(i, groupName){
                if (groupName != "") {
                    groupNames[i + 1] = groupName; // Must use +1 because "All" is our existing default.
                    if (groupName == sampleGroup) {
                        selectedGroup = i + 1; // Keep up with the last selected group, if present.
                    }
                }
            });

            if (selectedGroup == 0) {
                sampleGroup = "";
            }

            fldSampleGroup.dataSource.data(groupNames); // Populate dropdown with names.
            fldSampleGroup.select(selectedGroup); // Select the group found in the list.
            setSampleGroup(sampleGroup); // Set the group and obtain agent-session stats.
        } else {
            // Sample group field is unavailable, so obtain all agent-sessions regardless of group.
            getAgentSessions(selected.appServerUUID, "");
        }
    }

    function setSampleGroup(sampleGroup){
        // Remember the last group selected.
        var context = getAppContext();
        context.lastSampleGroup[context.lastServerUUID] = sampleGroup;
        setAppContext(context);

        // Clear the current profiler info until a data point is chosen.
        var grid = $("#mainContent div[name=profilerList]").getKendoGrid();
        if (grid) {
            grid.dataSource.data([]); // Reset grid options.
            $("#profilerData").val(""); // Reset text display.
        }

        // Get the latest list of agents/sessions for this server/group.
        getAgentSessions(context.lastServerUUID, sampleGroup);

        if (context.lastSessionID && context.lastTabSelected) {
            changeTab(context.lastTabSelected, context.lastSessionID, context.lastSessionUUID);
        } else {
            refreshTab(); // Refresh the current tab as a result of any updated values.
        }
    }

    function setAgentSession(selected){
        // Remember the last agent-session selected.
        var context = getAppContext();
        context.lastAgentPID = selected.agentPID || 0;
        context.lastSessionID = selected.sessionID || 0;
        context.lastSessionUUID = selected.agentSessionUUID || "";
        setAppContext(context);

        // Clear the current profiler info until a data point is chosen.
        var grid = $("#mainContent div[name=profilerList]").getKendoGrid();
        if (grid) {
            grid.dataSource.data([]); // Reset grid options.
            $("#profilerData").val(""); // Reset text display.
        }

        refreshTab(); // Refresh the current tab as a result of any updated values.
    }

    function refreshTab(tabSelected) {
        var context = getAppContext();

        // Rely on the last tab selected if none provided explicitly.
        if (!tabSelected || tabSelected == "") {
            tabSelected = context.lastTabSelected || "overview"; // Use selected or go with the first tab.
        }

        // Load certain data on-demand as the user selects a tab.
        switch (tabSelected) {
            case 0:
            case "overview":
            case "Overview":
                // Update the statistics overview using the selected server/application and group.
                getAgentSessions(context.lastServerUUID, context.lastSampleGroup[context.lastServerUUID])
                break;

            case 1:
            case "health":
            case "Health Trends":
                // Load health trend data for this server.
                getHealthTrends(context.lastServerUUID, 1);
                break;

            case 2:
            case "agent":
            case "Agent Activity":
                // Load all agent-session metrics for the current server/application/agent.
                getSessionChartData(context.lastServerUUID, context.lastAgentPID, context.lastSampleGroup[context.lastServerUUID]);
                break;

            case 3:
            case "session":
            case "Session Activity":
                // Load all memory and object datapoints, along with request activity/details.
                getMemoryChartData(context.lastServerUUID, context.lastAgentPID, context.lastSessionID, context.lastSampleGroup[context.lastServerUUID]);
                getRequestData(context.lastSessionUUID, context.lastSampleGroup[context.lastServerUUID]);
                break;

            /*
            case 4:
            case "profiler":
            case "Profiler Data":
                // Load list of profiler output for current session.
                getProfilerList(context.lastSessionUUID, null);
                break;

            case 5:
            case "agentlog":
            case "Agent Log":
                // Load server log for the current server/agent.
                getAgentLog(context.lastServerUUID, context.lastAgentPID);
                break;

            case 6:
            case "accesslog":
            case "Tomcat Access Log":
                // Load full access log for the current server.
                getAccessLog(context.lastServerUUID, context.lastSessionUUID);
                break;
            */

            default:
                console.log("Unknown tab value:", tabSelected);
        }
    }

    function updateChartScale(options, baseUnit, baseUnitStep){
        options.categoryAxis.baseUnit = baseUnit;
        options.categoryAxis.baseUnitStep = baseUnitStep;

        if (options.categoryAxis.baseUnit == "fit") {
            options.categoryAxis.title.text = "Sample Time";
        } else {
            options.categoryAxis.title.text = "Sample Time (Scale: " + options.categoryAxis.baseUnitStep + " " + options.categoryAxis.baseUnit + ")";
        }
    }

    function initContent(){
        // Get the current application context.
        var context = getAppContext();

        // Set some default values for context.
        if (context && !context.lastSampleGroup) {
            // This must be an object.
            context.lastSampleGroup = {};
        }
        setAppContext(context); // Store defaults to context.

        fldAppServer = $("#mainHeader input[name=appServerList]").kendoDropDownList({
            dataValueField: "appServerUUID",
            dataSource: new kendo.data.DataSource(),
            template: "#:serverName# / #:applicationName#",
            valueTemplate: "#:serverName# / #:applicationName#",
            select: function(e){
                var item = e.item || {};
                setAppServer(this.dataItem(item.index()) || {});
            }
        }).getKendoDropDownList();

        fldSampleGroup = $("#mainContent input[name=sampleGroupList]").kendoDropDownList({
            dataSource: new kendo.data.DataSource(),
            select: function(e){
                var item = e.item || {};
                setSampleGroup(this.dataItem(item.index()) || "");
            }
        }).getKendoDropDownList();

        var fldChartScale = $("#mainContent input[name=chartScale]").kendoDropDownList({
            dataSource: ["Fit", "Hours", "Minutes"],
            select: function(e){
                var item = e.item || {};
                var value = item.text();
                var context = getAppContext();
                context.chartScale = (value || "Fit");
                setAppContext(context);

                var baseUnitType = "Fit";
                var baseUnitStep = 2;
                switch(context.chartScale.toLowerCase()){
                    case "minutes":
                        baseUnitType = "minutes";
                        baseUnitStep = 15;
                        break;
                    case "hours":
                        baseUnitType = "hours";
                        baseUnitStep = 1;
                        break;
                    default:
                        baseUnitType = context.chartScale.toLowerCase();
                        break;
                }

                var chartSelectorAgent1 = "#mainContent div[name=chartAgentActivity]";
                if ($(chartSelectorAgent1).length) {
                    // Find the primary chart, and update accordingly.
                    var chartSess1 = $(chartSelectorAgent1).getKendoChart();
                    if (chartSess1) {
                        updateChartScale(chartSess1.options, baseUnitType, baseUnitStep);
                        chartSess1.redraw();
                    }
                }

                var chartSelectorAgent2 = "#mainContent div[name=chartAgentMemory]";
                if ($(chartSelectorAgent2).length) {
                    // Find the primary chart, and update accordingly.
                    var chartSess2 = $(chartSelectorAgent2).getKendoChart();
                    if (chartSess2) {
                        updateChartScale(chartSess2.options, baseUnitType, baseUnitStep);
                        chartSess2.redraw();
                    }
                }

                var chartSelectorAgent3 = "#mainContent div[name=chartAgentLife]";
                if ($(chartSelectorAgent3).length) {
                    // Find the primary chart, and update accordingly.
                    var chartSess3 = $(chartSelectorAgent3).getKendoChart();
                    if (chartSess3) {
                        updateChartScale(chartSess3.options, baseUnitType, baseUnitStep);
                        chartSess3.redraw();
                    }
                }

                var chartSelectorMemory = "#mainContent div[name=chartMemory]";
                if ($(chartSelectorMemory).length) {
                    // Find the primary chart, and update accordingly.
                    var chartMem = $(chartSelectorMemory).getKendoChart();
                    if (chartMem) {
                        updateChartScale(chartMem.options, baseUnitType, baseUnitStep);
                        chartMem.redraw();
                    }
                }

                var chartSelectorRequests = "#mainContent div[name=chartAgentRequests]";
                if ($(chartSelectorRequests).length) {
                    // Find the primary chart, and update accordingly.
                    var chartReq = $(chartSelectorRequests).getKendoChart();
                    if (chartReq) {
                        updateChartScale(chartReq.options, baseUnitType, baseUnitStep);
                        chartReq.redraw();
                    }
                }
            }
        }).getKendoDropDownList();

        // Set default value for chart scale selection.
        if (context && context.chartScale) {
            fldChartScale.value(context.chartScale);
        }

        var fldTrendPeriod = $("#mainContent input[name=trendPeriod]").kendoDropDownList({
            dataSource: [1, 2, 3, 6, 12, 24],
            select: function(e){
                var item = e.item || {};
                var value = item.text();
                getHealthTrends(getAppContext().lastServerUUID, value);
            }
        }).getKendoDropDownList();

        // Set default for trend period.
        fldTrendPeriod.value(1);

        $("#tabstrip").kendoTabStrip({
            animation: false,
            collapsible: false,
            select: function(e){
                // Get the name of the selected tab.
                var item = e.item || {};
                var value = item.innerText;

                // Remember this selected tab by name.
                var context = getAppContext();
                context.lastTabSelected = value;
                setAppContext(context);

                refreshTab(value); // Refresh the appropriate tab contents.
            }
        });
        var tabStrip = $("#tabstrip").getKendoTabStrip();
        if (tabStrip) {
            tabStrip.select(0); // Select (expand) the first tab by default.
        }

        // Create tab strips for charts/tables.
        $("#agentChartStrip").kendoTabStrip({
            animation: false,
            collapsible: false
        });
        var tabStrip = $("#agentChartStrip").getKendoTabStrip();
        if (tabStrip) {
            tabStrip.select(0); // Select (expand) the first tab by default.
        }
        $("#sessionChartStrip").kendoTabStrip({
            animation: false,
            collapsible: false
        });
        var tabStrip = $("#sessionChartStrip").getKendoTabStrip();
        if (tabStrip) {
            tabStrip.select(0); // Select (expand) the first tab by default.
        }

        $("#mainContent div[name=profilerList]").kendoGrid({
            columns: [{
                field: "sessionSampleUUID",
                hidden: true
            }, {
                field: "timestamp",
                template: "#=kendo.toString(new Date(timestamp), 'M/d/yy @ H:mm:ss.fff')# (#=kendo.toString(profileSize, 'n0')# KB)",
                title: "Profiler Output Time"
            }],
            dataSource: [],
            groupable: false,
            pageable: {
                numeric: false,
                pageSize: 10
            },
            scrollable: true,
            selectable: "row",
            sortable: false,
            change: function(ev){
                var grid = ev.sender;
                if (grid) {
                    var record = grid.dataItem(grid.select());
                    if (record) {
                        getProfilerData("output", record.profilerRec);
                    }
                }
            }
        });

        $("#mainContent div[name=requestList]").kendoGrid({
            columns: [{
                field: "requestNum",
                attributes: {class: "numbers"},
                title: "Request",
                width: 100
            }, {
                field: "startTime",
                title: "Start",
                width: 200
            }, {
                field: "endTime",
                title: "End",
                width: 200
            }, {
                field: "elapsedTime",
                attributes: {class: "numbers"},
                template: "#=kendo.toString((elapsedTime / 1000), 'n3')#s",
                title: "Elapsed",
                width: 100
            }, {
                field: "requestID",
                title: "Request ID",
                width: 160
            }, {
                field: "programName",
                title: "Request Procedure Name"
            }, {
                field: "hasCallTree",
                template: function(dataItem){
                    if (dataItem.hasCallTree) {
                        return '<a href="javascript:app.getCallTreeData(\'' + dataItem.requestUUID + '\')">View</a>';
                    } else {
                        return "";
                    }
                },
                title: "CallTree",
                width: 80
            }, {
                field: "hasProfiler",
                template: function(dataItem){
                    if (dataItem.hasProfiler) {
                        return '<a href="javascript:app.getProfilerData(\'' + dataItem.requestUUID + '\', \'' + dataItem.profilerRec + '\')">View</a>';
                    } else {
                        return "";
                    }
                },
                title: "Profiler",
                width: 80
            }],
            dataSource: new kendo.data.DataSource(),
            detailInit: requestDetailInit,
            excel: {
                fileName: "Requests.xlsx"
            },
            scrollable: true,
            selectable: "row",
            sortable: true,
            toolbar: ["excel"]
        });

        function requestDetailInit(ev) {
            var detailColumns = [{
                field: "line",
                attributes: {class: "numbers"},
                title: "Line #",
                width: 100
            }, {
                field: "routine",
                title: "Routine"
            }, {
                field: "source",
                title: "Source"
            }];

            $("<div/>").appendTo(ev.detailCell).kendoGrid({
                autoBind: true,
                columns: detailColumns,
                dataSource: ev.data.requestStack || [],
                scrollable: true,
                selectable: false
            });
        }

        $("#mainContent div[name=agentLog]").kendoGrid({
            columns: [{
                field: "msgNum",
                attributes: {class: "numbers"},
                title: "Ln\#",
                width: 80
            }, {
                field: "timestamp",
                title: "Date/Time",
                width: 240
            }, {
                field: "webAppName",
                title: "WebApp",
                width: 100
            }, {
                field: "transport",
                title: "Tx",
                width: 50
            }, {
                field: "requestID",
                title: "Req. ID",
                width: 100
            }, {
                field: "msgType",
                title: "Type",
                width: 120
            }, {
                field: "msgText",
                title: "Message"
            }],
            dataSource: new kendo.data.DataSource(),
            excel: {
                fileName: "AgentLog.xlsx"
            },
            scrollable: true,
            selectable: "row",
            sortable: true,
            toolbar: ["excel"]
        });

        $("#mainContent div[name=accessList]").kendoGrid({
            columns: [{
                field: "accessOrder",
                attributes: {class: "numbers"},
                title: "Ln\#",
                width: 50
            }, {
                field: "transport",
                title: "Tx",
                width: 50
            }, {
                field: "requestID",
                title: "Req. ID",
                width: 100
            }, {
                field: "requestStart",
                title: "Start",
                width: 200
            }, {
                field: "requestEnd",
                title: "End",
                width: 200
            }, {
                field: "webAppName",
                hidden: true,
                title: "WebApp",
                width: 100
            }, {
                field: "requestUser",
                hidden: true,
                title: "Req. User",
                width: 150
            }, {
                field: "requestVerb",
                title: "Method",
                width: 100
            }, {
                field: "requestPath",
                title: "Path"
            }, {
                field: "responseCode",
                attributes: {class: "numbers"},
                title: "Response",
                width: 100
            }, {
                field: "responseSize",
                attributes: {class: "numbers"},
                template: "#=kendo.toString((responseSize / 1024), 'n2')#kb",
                title: "Size",
                width: 140
            }, {
                field: "responseTime",
                attributes: {class: "numbers"},
                template: "#=kendo.toString((responseTime / 1000), 'n2')#s",
                title: "Time",
                width: 100
            }, {
                field: "overheadTime",
                attributes: {class: "numbers"},
                template: "#=kendo.toString((overheadTime / 1000), 'n2')#s",
                title: "Overhead",
                width: 120
            }],
            dataSource: new kendo.data.DataSource(),
            detailInit: accessDetailInit,
            excel: {
                fileName: "AccessLog.xlsx"
            },
            scrollable: true,
            selectable: "row",
            sortable: true,
            toolbar: ["excel"]
        });

        function accessDetailInit(ev) {
            var detailColumns = [{
                field: "requestNum",
                attributes: {class: "numbers"},
                title: "Request",
                width: 100
            }, {
                field: "startTime",
                title: "Start",
                width: 190
            }, {
                field: "endTime",
                title: "End",
                width: 190
            }, {
                field: "elapsedTime",
                attributes: {class: "numbers"},
                template: "#=kendo.toString((elapsedTime / 1000), 'n3')#s",
                title: "Elapsed",
                width: 100
            }, {
                field: "programName",
                title: "Request Procedure Name"
            }];

            $("<div/>").appendTo(ev.detailCell).kendoGrid({
                autoBind: true,
                columns: detailColumns,
                dataSource: ev.data.sessionRequest || [],
                scrollable: true,
                selectable: false
            });
        }

        $("#mainContent div[name=agentList]").kendoGrid({
            columns: [{
                field: "agentDisplay",
                title: "Agent",
                template: function(dataItem){
                    return '<a href="javascript:app.changeTab(\'agent\', \'' + dataItem.sessionID + '\', \'' + dataItem.agentSessionUUID + '\')">' + kendo.toString(dataItem.agentDisplay) + ' #' + kendo.toString(dataItem.sessionID, 'n0') + '</a>';
                },
                width: 100
            }, {
                hidden: true,
                field: "sessionID",
                title: "Session ID",
                width: 100
            }, {
                hidden: true,
                field: "startedTime",
                template: "#=startedDate# @ #=startedTime#",
                title: "First Appearance",
                width: 200
            }, {
                field: "elapsedRuntime",
                template: function(dataItem){
                    return '<span title="' + dataItem.startedDate + ' @ ' + dataItem.startedTime + '">' + dataItem.elapsedRuntime + '</span>';
                },
                title: "Elapsed Runtime",
                width: 140
            }, {
                field: "memoryMin",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "#=kendo.toString((sum / 1024), 'n1')#",
                template: "#=kendo.toString((memoryMin / 1024), 'n1')#",
                title: "Min Mem. (MB)",
                width: 150
            }, {
                field: "memoryMax",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "#=kendo.toString((sum / 1024), 'n1')#",
                template: function(dataItem){
                    return '<a href="javascript:app.changeTab(\'memory\', \'' + dataItem.sessionID + '\', \'' + dataItem.agentSessionUUID + '\')">' + kendo.toString(dataItem.memoryMax / 1024, 'n1') + '</a>';
                },
                title: "Max Mem. (MB)",
                width: 150
            }, {
                field: "memoryAvg",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "Avg: #=kendo.toString((average / 1024), 'n1')#",
                template: "#=kendo.toString((memoryAvg / 1024), 'n1')#",
                title: "Avg. Mem. (MB)",
                width: 150
            }, {
                field: "memoryDelta",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "#=kendo.toString((sum / 1024), 'n1')#",
                template: "#=kendo.toString((memoryDelta / 1024), 'n1')#",
                title: "Delta (MB)",
                width: 110
            }, {
                field: "objectMax",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                template: function(dataItem){
                    return '<a href="javascript:app.changeTab(\'objects\', \'' + dataItem.sessionID + '\', \'' + dataItem.agentSessionUUID + '\')">' + kendo.toString(dataItem.objectMax, 'n0') + '</a>';
                },
                title: "Max Objects",
                width: 130
            }, {
                field: "requestTimeAvg",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "Avg: #=kendo.toString(average, 'n3')#",
                template: function(dataItem){
                    return '<a href="javascript:app.changeTab(\'responses\', \'' + dataItem.sessionID + '\', \'' + dataItem.agentSessionUUID + '\')">' + kendo.toString(dataItem.requestTimeAvg, 'n1') + '</a>';
                },
                title: "Avg. Response (ms)",
                width: 130
            }, {
                field: "requestCount",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "#=kendo.toString(sum, 'n0')#",
                template: "#=kendo.toString(requestCount, 'n0')#",
                template: function(dataItem){
                    return '<a href="javascript:app.changeTab(\'requests\', \'' + dataItem.sessionID + '\', \'' + dataItem.agentSessionUUID + '\')">' + kendo.toString(dataItem.requestCount, 'n0') + '</a>';
                },
                title: "# Requests",
                width: 100
            }, {
                field: "requestPercent",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "#=kendo.toString(sum, 'n2')# %",
                template: "#=kendo.toString(requestPercent, 'n2')# %",
                title: "Req. %",
                width: 90
            }, {
                field: "requestPerSec",
                attributes: {class: "numbers"},
                footerAttributes: {class: "numbers"},
                groupFooterTemplate: "Avg: #=kendo.toString(average, 'n3')#",
                template: "#=kendo.toString(requestPerSec, 'n3')#",
                title: "Requests/Sec",
                width: 130
            }],
            dataSource: new kendo.data.DataSource({
                group: {
                    field: "agentDisplay",
                    aggregates: [{
                        field: "memoryMin",
                        aggregate: "sum"
                    }, {
                        field: "memoryMax",
                        aggregate: "sum"
                    }, {
                        field: "memoryAvg",
                        aggregate: "average"
                    }, {
                        field: "memoryDelta",
                        aggregate: "sum"
                    }, {
                        field: "requestTimeAvg",
                        aggregate: "average"
                    }, {
                        field: "requestCount",
                        aggregate: "sum"
                    }, {
                        field: "requestPercent",
                        aggregate: "sum"
                    }, {
                        field: "requestPerSec",
                        aggregate: "average"
                    }]
                },
                sort: [{
                    field: "sessionSort", dir: "asc"
                }]
            }),
            excel: {
                fileName: "AgentSessions.xlsx"
            },
            scrollable: true,
            selectable: "row",
            sortable: true,
            toolbar: ["excel"]
        });

        $("#objWindow").kendoWindow({
            actions: ["Close"],
            height: 600,
            title: "ABL Objects",
            visible: false,
            width: 1000
        });

        $("#objWindow div[name=objGrid]").kendoGrid({
            columns: [{
                field: "handleId",
                groupable: false,
                title: "Handle",
                width: 80
            }, {
                field: "source",
                title: "Source"
            }, {
                field: "line",
                groupable: false,
                title: "Line #",
                width: 80
            }, {
                field: "origReqId",
                title: "Req #",
                width: 80
            }, {
                field: "name",
                title: "Name"
            }, {
                field: "objType",
                title: "Object Type"
            }, {
                field: "objSize",
                title: "Size"
            }],
            dataSource: [],
            excel: {
                fileName: "ABLObjects.xlsx"
            },
            groupable: true,
            scrollable: true,
            sortable: false,
            toolbar: ["excel"]
        });

        // Get the initial data for the monitor, starting with a servers list.
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: "",
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/servers",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.appServer) {
                    // Update the selection list with results.
                    var servers = data.appServer || [];
                    fldAppServer.dataSource.data(servers);

                    if (servers.length > 0) {
                        var context = getAppContext();
                        var firstServer = servers[0] || {};
                        var found = false;
                        var lastUUID = context.lastServerUUID || "";
                        if (lastUUID == "") {
                            // Load the first application by default if no context exists.
                            setAppServer(firstServer);
                            fldAppServer.select(0);
                            found = true;
                        } else {
                            // Find a valid, current application via the last selected UUID.
                            var index = 0;
                            $.each(servers, function(i, server){
                                if (server.appServerUUID == lastUUID) {
                                    found = true;
                                    setAppServer(server);
                                    index = i;
                                }
                            });
                            fldAppServer.select(index);
                        }

                        if (!found) {
                            // If nothing found then the context may be out of date.
                            // Clear the context object and select the first server.
                            setAppServer(firstServer);
                            fldAppServer.select(0);
                            context.lastServerUUID = firstServer.appServerUUID || "";
                            setAppContext(context);
                        }
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
            }
        });
    }

    function getAgentSessions(appServerUUID, sampleGroup){
        // Returns all agent-sessions for the server/application and a group.
        var params = {
            serverUUID: appServerUUID || "",
            sampleGroup: sampleGroup || ""
        };

        // Clear the last grid contents.
        var grid = $("#mainContent div[name=agentList]").getKendoGrid();
        if (grid) {
            grid.dataSource.data([]);
        }

        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(params),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/sessions",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.agentSession) {
                    var context = getAppContext();

                    // Update the selection list and select the last item by default.
                    agentSessions = data.agentSession || [];

                    if (agentSessions.length > 0) {
                        // Make sure the current agent PID is found in the results.
                        var agentFound = false;
                        $.each(agentSessions || [], function(index, agentSession){
                            if (!agentFound && agentSession.agentPID == context.lastAgentPID) {
                                agentFound = true;
                            }
                        });

                        // If no agent/session previously selected then set defaults from the first entry.
                        if (!agentFound || !context.lastSessionUUID) {
                            context.lastAgentPID = (agentSessions[0] || {}).agentPID || 0;
                            context.lastSessionID = (agentSessions[0] || {}).sessionID || 0;
                            context.lastSessionUUID = (agentSessions[0] || {}).agentSessionUUID || "";
                            setAppContext(context);
                        }

                        // Prepare grid for agent/session data for this server/application.
                        var grid = $("#mainContent div[name=agentList]").getKendoGrid();
                        if (grid) {
                            grid.dataSource.data(agentSessions);
                        }
                    }
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getMemoryChartData(serverUUID, agentPID, sessionID, sampleGroup){
        var params = {
            serverUUID: serverUUID || "",
            agentPID: agentPID || 0,
            sessionID: sessionID || 0,
            sampleGroup: sampleGroup || ""
        };

        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(params),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/metrics",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.agentMetrics) {
                    // Update the chart for a specific agent-session of this server/application.
                    var metrics = data.agentMetrics || {};
                    var agents = metrics.instanceAgent || [];
                    // Display currently-selected session for the currently-selected agent.
                    var agentSession = (agents[0] || {}).agentSession || [];
                    var agent = agentSession[0] || {};
                    showMemoryChart(agent.sessionStat || []);
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getSessionChartData(serverUUID, agentPID, sampleGroup){
        var params = {
            serverUUID: serverUUID || "",
            agentPID: agentPID || 0,
            sessionID: 0,
            sampleGroup: sampleGroup || ""
        };

        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(params),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/metrics",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.agentMetrics) {
                    // Update the chart for all agent-sessions for this server/application.
                    var metrics = data.agentMetrics || {};
                    var agents = metrics.instanceAgent || [];
                    // Display only data for the currently-selected agent.
                    showAgentActivityChart(agents[0] || {});
                    showAgentRequestChart(agents[0] || {});
                    showAgentMemoryChart(agents[0] || {});
                    showAgentLifeChart(agents[0] || {});
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getAgentLog(appServerUUID, agentPID) {
        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({serverUUID: appServerUUID, agentPID: agentPID, dateRange: [null, null]}),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/logs",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.logData) {
                    var grid = $("#mainContent div[name=agentLog]").getKendoGrid();
                    if (grid) {
                        grid.dataSource.data(data.logData || []);
                    }
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getAccessLog(appServerUUID, sessionUUID) {
        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({serverUUID: appServerUUID, sessionUUID: sessionUUID}),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/access",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.accessHistory) {
                    var log = data.accessHistory || {};
                    var access = log.tomcatAccess || [];
                    var grid = $("#mainContent div[name=accessList]").getKendoGrid();
                    if (grid) {
                        grid.dataSource.data(access);
                    }
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getRequestData(agentSessionID, sampleGroup) {
        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({sessionUUID: agentSessionID, sampleGroup: sampleGroup}),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/requests",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.ablRequestStack) {
                    var ablReq = data.ablRequestStack || {};
                    var requests = ablReq.ablRequest || [];

                    // Update the request table data.
                    var grid = $("#mainContent div[name=requestList]").getKendoGrid();
                    if (grid) {
                        grid.dataSource.data(requests);
                    }
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getProfilerList(agentSessionID, timestamp){
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({sessionUUID: agentSessionID, requestDate: timestamp}),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/profilerList",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.profilerList) {
                    var grid = $("#mainContent div[name=profilerList]").getKendoGrid();
                    if (grid) {
                        grid.dataSource.data(data.profilerList);
                        var tabStrip = $("#tabstrip").getKendoTabStrip();
                        if (tabStrip) {
                            tabStrip.select(6); // Select the profiler tab.
                        }
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
            }
        });
    }

    function getCallTreeData(requestUUID){
        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({requestUUID: requestUUID}),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/callTree",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.callTreeData) {
                    // Immediately prompt to save contents as a file.
                    saveAsFile(data.callTreeData || "", "calltree_" + requestUUID + ".prof");
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getProfilerData(requestUUID, profilerRec){
        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({profilerRowID: profilerRec}),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/profilerData",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.profilerOut) {
                    // Immediately prompt to save contents as a file.
                    saveAsFile(data.profilerOut || "", "profiler_" + requestUUID + ".prof");
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function getObjectData(objectCount, sampleUUID, sampleDate){
        var params = {
            objectCount: objectCount,
            sampleUUID: sampleUUID,
            sampleGroup: "",
            sampleDate: sampleDate
        };

        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(params),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/objects",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.sampleObject) {
                    var ablObjects = data.sampleObject || [];
                    var title = "ABL Objects: " + kendo.toString(objectCount, "n0") + " @ " + kendo.toString(new Date(sampleDate), "M/d/yy @ H:mm:ss.fff");
                    showObjectData(title, ablObjects);
                }
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
            }
        });
    }

    function getHealthTrends(appServerUUID, trendTime) {
        kendo.ui.progress($("#tabstrip"), true);
        $.ajax({
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({serverUUID: appServerUUID, trendPeriod: trendTime || 0}),
            dataType: "json",
            url: "http://" + appHost + ":" + appPort + "/web/pdo/monitor/report/health",
            method: "put",
            success: function(data, textStatus, jqXHR){
                if (data.healthTrend) {
                    var trends = data.healthTrend || {};
                    showHealthChart(trends.healthProbe || []);
                }
                kendo.ui.progress($("#tabstrip"), false);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if (jqXHR.status == 401 || jqXHR.status == 403) {
                    console.log("Login Required");
                } else {
                    var errors = null;
                    var errMsg = errorThrown;
                    try {
                        errors = JSON.parse(jqXHR.responseText);
                    }
                    catch(e){}

                    if (errors && errors._errors) {
                        $.each(errors._errors, function(i, error){
                            errMsg += "\n" + error._errorMsg;
                        });
                    }
                    console.log("Error", errMsg);
                }
                kendo.ui.progress($("#tabstrip"), false);
            }
        });
    }

    function showObjectData(title, ablObjects){
        var window = $("#objWindow").getKendoWindow();
        if (window) {
            window.center().open();
            window.title(title);

            var grid = $("#objWindow div[name=objGrid]").getKendoGrid();
            if (grid) {
                grid.options.excel.fileName = "ABLObjects_A" + getAppContext().lastAgentPID + "_S" + getAppContext().lastSessionID + ".xlsx";
                grid.dataSource.data(ablObjects);
            }
        }
    }

    function showMemoryChart(data){
        var chartSelector = "#mainContent div[name=chartMemory]";
        if ($(chartSelector).length) {
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                // Destroy the last instance of this chart from the DOM.
                kendo.destroy($(chartSelector).children());
                $(chartSelector).empty();
            }

            var options = Charting.getChartOptions("memory");
            options.title.text = options.title.text + " (" + getAgentSessionInfo() + ")";

            // Adjust defaults for chart scale and steps.
            var context = getAppContext();
            if (context && context.chartScale && options.categoryAxis) {
                switch(context.chartScale.toLowerCase()){
                    case "minutes":
                        options.categoryAxis.baseUnit = "minutes";
                        options.categoryAxis.baseUnitStep = 15;
                        break;
                    case "hours":
                        options.categoryAxis.baseUnit = "hours";
                        options.categoryAxis.baseUnitStep = 1;
                        break;
                    default:
                        options.categoryAxis.baseUnit = context.chartScale.toLowerCase();
                        break;
                }
            }

            options.seriesClick = function(e){
                if (e.originalEvent.type === "contextmenu") {
                    // Disable browser context menu.
                    e.originalEvent.preventDefault();
                } else {
                    // Open a detail pane with more info.
                    var axis = (e.series || {}).axis || "";
                    if (axis === "memory") {
                        var sessionID = (e.dataItem || {}).sessionID || 0;
                        var agentSessionID = (e.dataItem || {}).agentSessionUUID || "";
                        changeTab("requests", sessionID, agentSessionID);
                    }
                    if (axis === "objects") {
                        var objectCount = (e.dataItem || {}).objectCount || 0;
                        var sampleUUID = (e.dataItem || {}).sessionSampleUUID || "";
                        var sampleDate = (e.dataItem || {}).dateSample || "";
                        if (objectCount > 0) {
                            // Display window if more than 0 objects for sample point.
                            getObjectData(objectCount, sampleUUID, sampleDate);
                        }
                    }
                }
            }

            chart = $(chartSelector).kendoChart(options).getKendoChart();
            chart.dataSource.data(data);
        }
    }

    function showAgentActivityChart(agentData){
        var chartSelector = "#mainContent div[name=chartAgentActivity]";
        if ($(chartSelector).length) {
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                // Destroy the last instance of this chart from the DOM.
                kendo.destroy($(chartSelector).children());
                $(chartSelector).empty();
            }

            var options = {
                legend: {
                    position: "right"
                },
                series: [],
                seriesClick: function(e){
                    if (e.originalEvent.type === "contextmenu") {
                        // Disable browser context menu.
                        e.originalEvent.preventDefault();
                    }
                },
                title: {
                    font: "20px sans-serif",
                    text: "Agent " + (agentData.agentPID || "") + " - Concurrent Sessions (" + getSimpleServerName() + ")"
                },
                tooltip: {
                    template: "#=series.name#: #=kendo.toString(value, 'n0')#",
                    visible: true
                },
                valueAxis: [{
                    name: "sessionBusy",
                    title: {
                        text: "Busy Sessions"
                    }
                }, {
                    name: "sessionReqs",
                    title: {
                        text: "Requests Served"
                    }
                }],
                categoryAxis: {
                    axisCrossingValues: [0, 5000],
                    baseUnit: "seconds",
                    baseUnitStep: 20,
                    categories: [],
                    labels: {
                        rotation: "auto"
                    },
                    title: {
                        text: "Sample Time"
                    },
                    type: "date"
                }
            };

            if (agentData.agentStat) {
                // Start with a series (as area chart) for the peak/busy sessions of this agent.
                var agentReqs = {
                    axis: "sessionReqs",
                    color: "#111111",
                    data: [],
                    name: "# Requests",
                    opacity: 0.5,
                    type: "line",
                    width: 2
                };
                var agentMem = {
                    axis: "sessionBusy",
                    color: "#0000AA",
                    data: [],
                    name: "Concurrent",
                    opacity: 0.3,
                    type: "area",
                    width: 2
                };

                var sessionSeries = {};

                // The list of agent sessions should contain all samples, so we use this for the list of dates.
                $.each(agentData.agentStat, function(i, agentStat){
                    // Capture the sample date/time for the category axis.
                    options.categoryAxis.categories.push(new Date(agentStat.dateSample));

                    if (agentStat.sessionActivity) {
                        $.each(agentStat.sessionActivity, function(j, agentSession){
                            var name = "S" + agentSession.sessionID;
                            if (!sessionSeries[name]) {
                                // Create a new series for this session.
                                sessionSeries[name] = {
                                    axis: "sessionReqs",
                                    data: [],
                                    name: name,
                                    type: "line",
                                    width: 2
                                };

                                if (options.categoryAxis.categories.length > 1) {
                                    sessionSeries[name].data = Array.apply(null, Array(options.categoryAxis.categories.length));
                                }
                            }
                            // Add the current request count to the existing data array.
                            sessionSeries[name].data.push(agentSession.requestCount);
                        });
                    }

                    // Add data to the agent-level series (total requests, busy/concurrent sessions).
                    agentReqs.data.push(agentStat.requestCount);
                    agentMem.data.push(agentStat.busySessions);
                });

                // Set the steps for the category axis to something reasonable based on the number of results and interval between them.
                if (options.categoryAxis.categories.length > 2) {
                    var dateStart = options.categoryAxis.categories[0].getTime();
                    var dateEnd = options.categoryAxis.categories[options.categoryAxis.categories.length - 1].getTime();
                    var interval = (dateEnd - dateStart) / 1000; // Get difference in seconds.
                    var timespan = parseInt(interval / 60, 10); // Get minutes from interval.
                    if (timespan / 60 > 1) {
                        // If timespan is more than an hour, we need bigger steps (using minutes).
                        updateChartScale(options, "minutes", (parseInt(timespan / 60, 10) * 2));
                    }
                }

                $.each(sessionSeries, function(name, series){
                    options.series.push(series);
                });
                if (agentReqs.data.length > 0) {
                    options.series.push(agentReqs);
                }
                if (agentMem.data.length > 0) {
                    options.series.push(agentMem);
                }
            }

            $(chartSelector).kendoChart(options).getKendoChart();
        }
    }

    function showAgentRequestChart(agentData){
        var chartSelector = "#mainContent div[name=chartAgentRequests]";
        if ($(chartSelector).length) {
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                // Destroy the last instance of this chart from the DOM.
                kendo.destroy($(chartSelector).children());
                $(chartSelector).empty();
            }

            var options = {
                legend: {
                    position: "right"
                },
                series: [],
                seriesClick: function(e){
                    if (e.originalEvent.type === "contextmenu") {
                        // Disable browser context menu.
                        e.originalEvent.preventDefault();
                    }
                },
                title: {
                    font: "20px sans-serif",
                    text: "Agent " + (agentData.agentPID || "") + " - Response Times (" + getSimpleServerName() + ")"
                },
                tooltip: {
                    template: "#=series.name#: #=kendo.toString(value, 'n0')#",
                    visible: true
                },
                valueAxis: [{
                    max: 500,
                    name: "sessionAvg",
                    title: {
                        text: "Avg. Duration (ms)"
                    }
                }, {
                    max: 500,
                    name: "sessionMax",
                    title: {
                        text: "Peak Duration (ms)"
                    }
                }],
                categoryAxis: {
                    axisCrossingValues: [0, 5000],
                    baseUnit: "seconds",
                    baseUnitStep: 20,
                    categories: [],
                    labels: {
                        rotation: "auto"
                    },
                    title: {
                        text: "Sample Time"
                    },
                    type: "date"
                }
            };

            if (agentData.agentStat) {
                // Start with a series (as area chart) for the peak response time for this agent.
                var maxResponse = {
                    axis: "sessionMax",
                    color: "#0000AA",
                    data: [],
                    name: "Peak Duration (ms)",
                    opacity: 0.3,
                    type: "area",
                    width: 2
                };

                var sessionSeries = {};
                var maxDuration = 0;
                var scaleMax = 500;

                // The list of agent sessions should contain all samples, so we use this for the list of dates.
                $.each(agentData.agentStat, function(i, agentStat){
                    // Capture the sample date/time for the category axis.
                    options.categoryAxis.categories.push(new Date(agentStat.dateSample));

                    if (agentStat.sessionActivity) {
                        maxDuration = 0; // Reset on each date sample.

                        $.each(agentStat.sessionActivity, function(j, agentSession){
                            var name = "S" + agentSession.sessionID;
                            if (!sessionSeries[name]) {
                                // Create a new series for this session.
                                sessionSeries[name] = {
                                    axis: "sessionAvg",
                                    data: [],
                                    name: name,
                                    type: "line",
                                    width: 2
                                };

                                if (options.categoryAxis.categories.length > 1) {
                                    sessionSeries[name].data = Array.apply(null, Array(options.categoryAxis.categories.length));
                                }
                            }
                            // Add the elapsed time values to the existing data arrays.
                            sessionSeries[name].data.push(agentSession.avgElapsed);
                            maxDuration = Math.max(maxDuration, agentSession.maxElapsed);
                            scaleMax = Math.max(scaleMax, (Math.trunc(agentSession.maxElapsed / 100) + 2) * 100);
                        });
                    }

                    // Add data to the agent-level series (max peak duration).
                    maxResponse.data.push(maxDuration);
                });

                // Set the steps for the category axis to something reasonable based on the number of results and interval between them.
                if (options.categoryAxis.categories.length > 2) {
                    var dateStart = options.categoryAxis.categories[0].getTime();
                    var dateEnd = options.categoryAxis.categories[options.categoryAxis.categories.length - 1].getTime();
                    var interval = (dateEnd - dateStart) / 1000; // Get difference in seconds.
                    var timespan = parseInt(interval / 60, 10); // Get minutes from interval.
                    if (timespan / 60 > 1) {
                        // If timespan is more than an hour, we need bigger steps (using minutes).
                        updateChartScale(options, "minutes", (parseInt(timespan / 60, 10) * 2));
                    }
                }

                // Set a consistent max value for both axis.
                options.valueAxis[0].max = scaleMax;
                options.valueAxis[1].max = scaleMax;

                $.each(sessionSeries, function(name, series){
                    options.series.push(series);
                });
                if (maxResponse.data.length > 0) {
                    options.series.push(maxResponse);
                }
            }

            $(chartSelector).kendoChart(options).getKendoChart();
        }
    }

    function showAgentMemoryChart(agentData){
        var chartSelector = "#mainContent div[name=chartAgentMemory]";
        if ($(chartSelector).length) {
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                // Destroy the last instance of this chart from the DOM.
                kendo.destroy($(chartSelector).children());
                $(chartSelector).empty();
            }

            var options = {
                legend: {
                    position: "right"
                },
                series: [],
                seriesClick: function(e){
                    if (e.originalEvent.type === "contextmenu") {
                        // Disable browser context menu.
                        e.originalEvent.preventDefault();
                    }
                },
                title: {
                    font: "20px sans-serif",
                    text: "Agent " + (agentData.agentPID || "") + " - Session Memory (" + getSimpleServerName() + ")"
                },
                tooltip: {
                    template: "#=series.name#: #=kendo.toString(value, 'n0')#",
                    visible: true
                },
                valueAxis: [{
                    majorUnit: 2,
                    name: "sessionMem",
                    title: {
                        text: "Memory (KB)"
                    },
                    type: "log"
                }, {
                    name: "sessionReqs",
                    title: {
                        text: "Requests Served"
                    }
                }],
                categoryAxis: {
                    axisCrossingValues: [0, 5000],
                    baseUnit: "seconds",
                    baseUnitStep: 20,
                    categories: [],
                    labels: {
                        rotation: "auto"
                    },
                    title: {
                        text: "Sample Time"
                    },
                    type: "date"
                }
            };

            if (agentData.agentStat) {
                // Start with a series (as area chart) for the peak/busy sessions of this agent.
                var agentReqs = {
                    axis: "sessionReqs",
                    color: "#111111",
                    data: [],
                    name: "# Requests",
                    opacity: 0.5,
                    type: "line",
                    width: 2
                };
                var agentMem = {
                    axis: "sessionMem",
                    color: "#11AA11",
                    data: [],
                    name: "Session Memory",
                    opacity: 0.3,
                    type: "area",
                    width: 2
                };

                var sessionSeries = {};
                // The list of agent sessions should contain all samples, so we use this for the list of dates.
                $.each(agentData.agentStat, function(i, agentStat){
                    // Capture the sample date/time for the category axis.
                    options.categoryAxis.categories.push(new Date(agentStat.dateSample));

                    if (agentStat.sessionActivity) {
                        $.each(agentStat.sessionActivity, function(j, agentSession){
                            var name = "S" + agentSession.sessionID;
                            if (!sessionSeries[name]) {
                                // Create a new series for this session.
                                sessionSeries[name] = {
                                    axis: "sessionMem",
                                    data: [],
                                    name: name,
                                    type: "line",
                                    width: 2
                                };

                                if (options.categoryAxis.categories.length > 1) {
                                    sessionSeries[name].data = Array.apply(null, Array(options.categoryAxis.categories.length));
                                }
                            }
                            // Add the current request count to the existing data array.
                            sessionSeries[name].data.push(agentSession.memoryBytes);
                        });
                    }

                    // Add data to the agent-level series (total requests, session memory).
                    agentReqs.data.push(agentStat.requestCount);
                    agentMem.data.push(agentStat.memoryBytes);
                });

                // Set the steps for the category axis to something reasonable based on the number of results and interval between them.
                if (options.categoryAxis.categories.length > 2) {
                    var dateStart = options.categoryAxis.categories[0].getTime();
                    var dateEnd = options.categoryAxis.categories[options.categoryAxis.categories.length - 1].getTime();
                    var interval = (dateEnd - dateStart) / 1000; // Get difference in seconds.
                    var timespan = parseInt(interval / 60, 10); // Get minutes from interval.
                    if (timespan / 60 > 1) {
                        // If timespan is more than an hour, we need bigger steps (using minutes).
                        updateChartScale(options, "minutes", (parseInt(timespan / 60, 10) * 2));
                    }
                }

                $.each(sessionSeries, function(name, series){
                    options.series.push(series);
                });
                if (agentReqs.data.length > 0) {
                    options.series.push(agentReqs);
                }
                if (agentMem.data.length > 0) {
                    options.series.push(agentMem);
                }
            }

            $(chartSelector).kendoChart(options).getKendoChart();
        }
    }

    function showAgentLifeChart(agentData){
        var chartSelector = "#mainContent div[name=chartAgentLife]";
        if ($(chartSelector).length) {
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                // Destroy the last instance of this chart from the DOM.
                kendo.destroy($(chartSelector).children());
                $(chartSelector).empty();
            }

            var options = {
                legend: {
                    position: "right"
                },
                series: [],
                seriesClick: function(e){
                    if (e.originalEvent.type === "contextmenu") {
                        // Disable browser context menu.
                        e.originalEvent.preventDefault();
                    }
                },
                title: {
                    font: "20px sans-serif",
                    text: "Agent " + (agentData.agentPID || "") + " - Lifetime (" + getSimpleServerName() + ")"
                },
                tooltip: {
                    template: "#=series.name#: #=kendo.toString(value, 'n0')#",
                    visible: true
                },
                valueAxis: [{
                    majorUnit: 2,
                    name: "sessionMem",
                    title: {
                        text: "Memory (KB)"
                    },
                    type: "log"
                }, {
                    name: "sessionCount",
                    title: {
                        text: "Session Count"
                    }
                }],
                categoryAxis: {
                    axisCrossingValues: [0, 5000],
                    baseUnit: "seconds",
                    baseUnitStep: 20,
                    categories: [],
                    labels: {
                        rotation: "auto"
                    },
                    title: {
                        text: "Sample Time"
                    },
                    type: "date"
                }
            };

            if (agentData.agentStat) {
                // Start with a series (as area chart) for the peak/busy sessions of this agent.
                var agentSess = {
                    axis: "sessionCount",
                    color: "#111111",
                    data: [],
                    name: "# Sessions",
                    opacity: 0.5,
                    type: "line",
                    width: 2
                };
                var agentMem = {
                    axis: "sessionMem",
                    color: "#008800",
                    data: [],
                    name: "Session Memory",
                    opacity: 0.5,
                    type: "line",
                    width: 2
                };
                var agentPeak = {
                    axis: "sessionMem",
                    color: "#11AA11",
                    data: [],
                    name: "Peak Memory",
                    opacity: 0.3,
                    type: "area",
                    width: 2
                };

                // The list of agent sessions should contain all samples, so we use this for the list of dates.
                $.each(agentData.agentStat, function(i, agentStat){
                    // Capture the sample date/time for the category axis.
                    options.categoryAxis.categories.push(new Date(agentStat.dateSample));

                    // Add data to the agent-level series (session count, session memory).
                    agentSess.data.push(agentStat.sessionActivity.length);
                    agentMem.data.push(agentStat.memoryBytes);
                    agentPeak.data.push(agentStat.overheadMem + agentStat.memoryPeak);
                });

                // Set the steps for the category axis to something reasonable based on the number of results and interval between them.
                if (options.categoryAxis.categories.length > 2) {
                    var dateStart = options.categoryAxis.categories[0].getTime();
                    var dateEnd = options.categoryAxis.categories[options.categoryAxis.categories.length - 1].getTime();
                    var interval = (dateEnd - dateStart) / 1000; // Get difference in seconds.
                    var timespan = parseInt(interval / 60, 10); // Get minutes from interval.
                    if (timespan / 60 > 1) {
                        // If timespan is more than an hour, we need bigger steps (using minutes).
                        updateChartScale(options, "minutes", (parseInt(timespan / 60, 10) * 2));
                    }
                }

                if (agentSess.data.length > 0) {
                    options.series.push(agentSess);
                }
                if (agentMem.data.length > 0) {
                    options.series.push(agentMem);
                }
                if (agentPeak.data.length > 0) {
                    options.series.push(agentPeak);
                }
            }

            $(chartSelector).kendoChart(options).getKendoChart();
        }
    }

    function showHealthChart(data){
        var chartSelector = "#mainContent div[name=chartHealth]";
        if ($(chartSelector).length) {
            var chart = $(chartSelector).getKendoChart();
            if (!chart) {
                // Destroy the last instance of this chart from the DOM.
                kendo.destroy($(chartSelector).children());
                $(chartSelector).empty();
            }

            var options = {
                legend: {
                    position: "right"
                },
                series: [],
                seriesClick: function(e){
                    if (e.originalEvent.type === "contextmenu") {
                        // Disable browser context menu.
                        e.originalEvent.preventDefault();
                    }
                },
                seriesDefaults: {
                    style: "smooth",
                    type: "scatterLine"
                },
                title: {
                    font: "20px sans-serif",
                    text: "Instance Health (" + getSimpleServerName() + ")"
                },
                tooltip: {
                    template: "#=series.name#: #=kendo.toString(value.y, 'n0')# @ #=kendo.toString(value.x, 'M/d/yy @ H:mm:ss.fff')#",
                    visible: true
                },
                xAxis: {
                    baseUnit: "seconds",
                    baseUnitStep: 20,
                    labels: {
                        rotation: "auto"
                    },
                    title: {
                        text: "Sample Time"
                    },
                    type: "date"
                },
                yAxis: {
                    max: 110,
                    title: {
                        text: "Health (%)"
                    }
                }
            };

            $.each(data, function(i, probe){
                var seriesData = {
                    data: [],
                    name: probe.probeName,
                    width: 2
                };

                $.each(probe.probeData, function(j, stat){
                    seriesData.data.push([new Date(stat.pollTime), stat.health]);
                });

                if (seriesData.data.length > 0) {
                    options.series.push(seriesData);
                }
            });
            $(chartSelector).kendoChart(options).getKendoChart();
        }
    }

    function exportMemoryChart(){
        var chartSelector = "#mainContent div[name=chartMemory]";
        if ($(chartSelector).length) {
            // Find the primary chart, and update accordingly.
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                chart.exportImage({
                    paperSize: "auto",
                    margin: {
                        left: "1cm",
                        top: "1cm",
                        right: "1cm",
                        bottom: "1cm"
                    }
                }).done(function(data) {
                    kendo.saveAs({
                        dataURI: data,
                        fileName: getFileSafeServerName() + "_MemoryObjects_A" + getAppContext().lastAgentPID + "_S" + getAppContext().lastSessionID + ".png"
                    });
                });
            }
        }
    }

    function exportAgentActivityChart(){
        var chartSelector = "#mainContent div[name=chartAgentActivity]";
        if ($(chartSelector).length) {
            // Find the primary chart, and update accordingly.
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                chart.exportImage({
                    paperSize: "auto",
                    margin: {
                        left: "1cm",
                        top: "1cm",
                        right: "1cm",
                        bottom: "1cm"
                    }
                }).done(function(data) {
                    kendo.saveAs({
                        dataURI: data,
                        fileName: getFileSafeServerName() + "_AgentActivity_A" + getAppContext().lastAgentPID + ".png"
                    });
                });
            }
        }
    }

    function exportAgentMemoryChart(){
        var chartSelector = "#mainContent div[name=chartAgentMemory]";
        if ($(chartSelector).length) {
            // Find the primary chart, and update accordingly.
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                chart.exportImage({
                    paperSize: "auto",
                    margin: {
                        left: "1cm",
                        top: "1cm",
                        right: "1cm",
                        bottom: "1cm"
                    }
                }).done(function(data) {
                    kendo.saveAs({
                        dataURI: data,
                        fileName: getFileSafeServerName() + "_AgentMemory_A" + getAppContext().lastAgentPID + ".png"
                    });
                });
            }
        }
    }

    function exportAgentLifeChart(){
        var chartSelector = "#mainContent div[name=chartAgentLife]";
        if ($(chartSelector).length) {
            // Find the primary chart, and update accordingly.
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                chart.exportImage({
                    paperSize: "auto",
                    margin: {
                        left: "1cm",
                        top: "1cm",
                        right: "1cm",
                        bottom: "1cm"
                    }
                }).done(function(data) {
                    kendo.saveAs({
                        dataURI: data,
                        fileName: getFileSafeServerName() + "_SessionLife_A" + getAppContext().lastAgentPID + ".png"
                    });
                });
            }
        }
    }

    function exportHealthChart(){
        var chartSelector = "#mainContent div[name=chartHealth]";
        if ($(chartSelector).length) {
            // Find the primary chart, and update accordingly.
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                chart.exportImage({
                    paperSize: "auto",
                    margin: {
                        left: "1cm",
                        top: "1cm",
                        right: "1cm",
                        bottom: "1cm"
                    }
                }).done(function(data) {
                    kendo.saveAs({
                        dataURI: data,
                        fileName: getFileSafeServerName() + "_Health.png"
                    });
                });
            }
        }
    }


    function exportRequestChart(){
        var chartSelector = "#mainContent div[name=chartAgentRequests]";
        if ($(chartSelector).length) {
            // Find the primary chart, and update accordingly.
            var chart = $(chartSelector).getKendoChart();
            if (chart) {
                chart.exportImage({
                    paperSize: "auto",
                    margin: {
                        left: "1cm",
                        top: "1cm",
                        right: "1cm",
                        bottom: "1cm"
                    }
                }).done(function(data) {
                    kendo.saveAs({
                        dataURI: data,
                        fileName: getFileSafeServerName() + "_RequestActivity_A" + getAppContext().lastAgentPID + "_S" + getAppContext().lastSessionID + ".png"
                    });
                });
            }
        }
    }

    function saveAsFile(textToWrite, filename) {
        var textFileAsBlob = new Blob([textToWrite], {type: "text/plain"});
        var downloadLink = document.createElement("a");
        downloadLink.download = filename;
        downloadLink.innerHTML = "Download File";
        if (window.webkitURL != null) {
            // Chrome allows the link to be clicked without actually adding it to the DOM.
            downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
        } else {
            // Firefox requires the link to be added to the DOM before it can be clicked.
            downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
            downloadLink.onclick = function(event){
                // Remove the link from the DOM.
                document.body.removeChild(event.target);
            };
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
        }
        downloadLink.click();
    }

    function changeTab(tabName, sessionID, agentSessionID) {
        var found = false;
        $.each(agentSessions || [], function(index, agentSession){
            // Determine the index of the session which was passed.
            if (!found && agentSession.agentSessionUUID == agentSessionID) {
                setAgentSession(agentSession);
                found = true;
            }
        });

        // Switch back to a default tab.
        var tabStrip = $("#tabstrip").getKendoTabStrip();
        var agentStrip = $("#agentChartStrip").getKendoTabStrip();
        var sessionStrip = $("#sessionChartStrip").getKendoTabStrip();
        if (tabStrip) {
            switch(tabName){
                case "overview":
                    tabStrip.select(0);
                    break;
                case "health":
                    tabStrip.select(1);
                    break;
                case "agent":
                    tabStrip.select(2);
                    break;
                case "responses":
                    tabStrip.select(2);
                    if (agentStrip) {
                        agentStrip.select(1);
                    }
                    break;
                case "memory":
                case "objects":
                    tabStrip.select(3);
                    if (sessionStrip) {
                        sessionStrip.select(0);
                    }
                    break;
                case "requests":
                    tabStrip.select(3);
                    if (sessionStrip) {
                        sessionStrip.select(1);
                    }
                    break;
                /*
                case "profiler":
                    tabStrip.select(4);
                    break;
                */
            }
        }
    }

    /***** Initialization *****/

    // Create a VM to be used by the header.
    var headerVM = kendo.observable({
        headerTitle: "Server/Application",
        goToAdmin: function(){
            location.href = "/static/admin.html";
        }
    });

    // Create a VM to be used by the content.
    var contentVM = kendo.observable({});

    $(document).ready(function(){
        // Load current culture.
        kendo.culture(langCode);

        kendo.bind($("#mainHeader"), headerVM); // Bind VM to header.
        kendo.bind($("#mainContent"), contentVM); // Bind VM to content.

        // Get text replacements based on language.
        getLanguageStrings("en-US");

        updateStyles(); // Load any default styles.
        initContent(); // Create content widgets.
    });

    /***** Public Object *****/

    return {
        logMessage: logMessage,
        showMessage: showMessage,
        showMessages: showMessages,
        translateView: translateView,
        getText: getText,
        headerVM: headerVM,
        getAppContext: getAppContext,
        setAppContext: setAppContext,
        changeTab: changeTab,
        refreshTab: refreshTab,
        getCallTreeData: getCallTreeData,
        getProfilerData: getProfilerData,
        exportMemoryChart: exportMemoryChart,
        exportAgentActivityChart: exportAgentActivityChart,
        exportAgentMemoryChart: exportAgentMemoryChart,
        exportAgentLifeChart: exportAgentLifeChart,
        exportHealthChart: exportHealthChart,
        exportRequestChart: exportRequestChart
    };

})();