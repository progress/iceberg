var Charting = (function(){
    "use strict";

    function getChartOptions(type){
        return {
            categoryAxis: {
                axisCrossingValues: [0, 5000],
                baseUnit: "minutes",
                baseUnitStep: 2,
                crosshair: {
                    visible: true
                },
                field: "dateSample",
                labels: {
                    rotation: "auto"
                },
                maxDateGroups: 20,
                type: "date"
            },
            dataSource: new kendo.data.DataSource({
                sort: {
                    field: "dateSample",
                    dir: "asc"
                }
            }),
            legend: {
                position: "bottom"
            },
            seriesDefaults: {
                style: "smooth",
                type: "line"
            },
            series: Charting.getChartSeries(type),
            title: {
                font: "20px sans-serif",
                text: Charting.getChartTitle(type)
            },
            tooltip: {
                template: "#=series.name#: #=kendo.toString(value, 'n0')# @ #=kendo.toString(new Date(dataItem.dateSample), 'M/d/yy @ H:mm:ss.fff')#",
                visible: true
            },
            valueAxis: Charting.getValueAxis(type)
        };
    }

    function getChartTitle(type){
        var title = "";

        switch(type){
        	case "memory":
        		title = "Session Memory/Objects";
            break;
        }

        return title;
    }

    function getChartSeries(type){
        var series = [];

        switch(type){
            case "memory":
                series = [{
                    aggregate: "max",
                    axis: "memory",
                    color: "#c14e00",
                    field: "memoryBytes",
                    name: "Memory (KB)",
                    width: 3,
                    markers: {
                        visible: true
                    }
                }, {
                    aggregate: "max",
                    axis: "objects",
                    color: "#0073c1",
                    field: "objectCount",
                    name: "Object Count",
                    width: 3,
                    markers: {
                        visible: true
                    }
                }];
                break;
            default:
            	console.log("No series configured for chart type '" + type + "'");
        }

        return series;
    }

    function getValueAxis(type){
        var valueAxis = [];

        switch(type){
	        case "memory":
	            valueAxis = [{
	                majorUnit: 2,
	                name: "memory",
	                color: "#c14e00",
	                labels: {
	                    template: "#=kendo.toString(value, 'n1')#"
	                },
	                title: {
	                	text: "Memory (KB)"
	                },
                    type: "log"
	            }, {
	                name: "objects",
	                color: "#0073c1",
	                labels: {
	                    template: "#=kendo.toString(value, 'n0')#"
	                },
	                title: {
	                	text: "Object Count"
	                }
	            }];
	            break;
	        default:
            	console.log("No value axis configured for chart type '" + type + "'");
        }

        return valueAxis;
    }

    return {
        getChartOptions: getChartOptions,
        getChartTitle: getChartTitle,
        getChartSeries: getChartSeries,
        getValueAxis: getValueAxis
    };

})();